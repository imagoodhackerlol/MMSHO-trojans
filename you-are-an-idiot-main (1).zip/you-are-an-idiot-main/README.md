<div align="center">
  <h1>You are an idiot!</h1>
  Recreation of the famous You Are An Idiot trojan
</div>

<br>

### Limitations
Modern web browsers do not let websites play sound without user interaction or
display bunch of popup dialogs, **so you need to interact
with the website (click around, allow popups etc.) in 
order to get the "full experience".**

And also you may want to turn down the volume!

When you are ready, [click here](https://ngn13.github.io/youareanidiot/index.html) to visit
the website

<br>

### How do I stop it???
Use `killall` command to kill your browser:
```bash
killall -9 firefox
```
Or use the task manager if you are on windows.
Another option is just to wait untill your browser or your computer crashes.

<br>

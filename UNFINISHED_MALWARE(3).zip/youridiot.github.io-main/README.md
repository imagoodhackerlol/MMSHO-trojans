# youridiot.github.io
whats gooood my guys? this is a unfinished super virus recreation of you are an idiot
## How did I make this?
I used Sublime Text for editing, and Oracle VM for testing it.

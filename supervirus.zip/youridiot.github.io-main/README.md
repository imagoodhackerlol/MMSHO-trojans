# youridiot.github.io
Trojan.JS.YouAreAnIdiot recreated in JS, HTML and CSS without using Flash.
## How did I make this?
I used Sublime Text for editing, and Oracle VM for testing it.
